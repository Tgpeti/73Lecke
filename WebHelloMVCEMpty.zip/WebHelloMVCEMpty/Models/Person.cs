﻿namespace WebHelloMVCEMpty.Models
{
    public class Person
    {

        public string nev { get; set; }
    }
}
